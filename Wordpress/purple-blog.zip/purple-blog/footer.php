<div id="footer" class="clearfix">
  <div class="wrapper">
    <div id="footer-recent-posts">
      <h2>Recent Posts</h2>
      <ul>
        <li> <a href="#">Purple - A Free CSS Template by Henry Jorge and TF. <br />
          <span>March 15, 2008</span></a> </li>
        <li> <a href="#">Purple - A Free CSS Template by Henry Jorge and TF. <br />
          <span>March 15, 2008</span></a> </li>
        <li> <a href="#">Purple - A Free CSS Template by Henry Jorge and TF. <br />
          <span>March 15, 2008</span></a> </li>
      </ul>
    </div>
    <div id="footer-recent-comments">
      <h2>Recent Comments</h2>
      <ul>
        <li><a href="#">Wow, great template! Good job both to Templatefusion and Henry Jorge! <br />
          <span>Happy Camper</span></a></li>
        <li><a href="#">Wow, great template! Good job both to Templatefusion and Henry Jorge! <br />
          <span>Happy Camper</span></a></li>
        <li><a href="#">Wow, great template! Good job both to Templatefusion and Henry Jorge! <br />
          <span>Happy Camper</span></a></li>
      </ul>
    </div>
    <div id="about">
      <h2>About</h2>
      <p id="info">This template was created by Henry Jorge, then recoded, touched up, and released by TemplateFusion.org</p>
      <p id="copyright"> Copyright &copy; 2007 <a href="#logo">My Site</a>&nbsp;<br />
        Designed by <a href="http://HenryJ.org">Henry Jorge</a><br />
        Released by <a href="http://templatefusion.org">TemplateFusion</a> </p>
      <p id="valid"> <span><a href="http://validator.w3.org/check?uri=referer">XHTML</a></span>&nbsp;&nbsp; <span><a href="#">CSS</a></span> </p>
    </div>
    <div class="clearing">&nbsp;</div>
  </div>
</div>