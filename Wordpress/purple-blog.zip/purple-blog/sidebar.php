<div id="sidebar">
    <ul>
      <li>
        <h2>Pages</h2>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#" title="About">About</a></li>
          <li><a href="#" title="Services">Services</a></li>
          <li><a href="#" title="Portfolio">Portfolio</a></li>
          <li><a href="#" title="Contact">Contact</a></li>
          <li><a href="#">Henry Jorge</a></li>
          <li><a href="#">TemplateFusion</a></li>
        </ul>
      </li>
      <li>
        <h2>Archives</h2>
        <ul>
          <li><a href="#">September 2008</a></li>
          <li><a href="#">October 2008</a></li>
          <li><a href="#">November 2008</a></li>
          <li><a href="#">December 2008</a></li>
        </ul>
      </li>
      <li>
        <h2>Categories</h2>
        <ul>
          <li><a href="#">Uncategorized</a></li>
        </ul>
      </li>
      <li>
        <h2>Blogroll</h2>
        <ul>
          <li><a href="#">TemplateFusion</a></li>
          <li><a href="#">Henry Jorge</a></li>
        </ul>
      </li>
      <li>
        <h2>Meta</h2>
        <ul>
          <li><a href="#">Login</a></li>
          <li><a href="#">WordPress</a></li>
        </ul>
      </li>
    </ul>
  </div>